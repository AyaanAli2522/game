var Cat,Rat,Cheese,Dark,Light,cardboard1,cardboard2,cardboard3,cardboard4,cardboard5,cardboard6,cardboard7,cardboard8,cardboard9,cardboard10,cardboard11,cardboard12,cardboard13,cardboard14,cardboard15,cardboard16,cardboard17,cardboard18,cardboard19,cardboard20,cardboard21,cardboard22,target,edges
function preload() {
  catImage=loadImage("PngItem_86648.png")
  ratImage=loadImage("favpng_rat-control-the-game-tap-on.png")
  cheeseImage=loadImage("Cheese.jpg")
  darkImage=loadImage("DARK.png")
  // lightImage=loadImage("LIGHT.png")
  // lightImage.scale=0.1
}

function setup() {
  createCanvas(600,600)
  Cat=createSprite(50,100,10,10)
  Cat.addImage(catImage)
  Cat.scale=0.04
  Rat=createSprite(350,200,10,10)
  Rat.addImage(ratImage)
  Rat.scale=0.1
    cardboard1 = createSprite(80,70,100,20);
   cardboard1.shapeColor = "white";
   cardboard2 = createSprite(120,110,20,100);
  cardboard2.shapeColor = "white";
   cardboard3 = createSprite(160,160,100,20);
  cardboard3.shapeColor = "brown";
   cardboard4 = createSprite(40,200,20,100);
  cardboard4.shapeColor = "brown";
   cardboard5 = createSprite(100,240,100,20);
   cardboard5.shapeColor = "brown";
   cardboard6 = createSprite(290,250,100,20);
   cardboard6.shapeColor = "brown";
   cardboard7 = createSprite(290,190,20,100);
   cardboard7.shapeColor = "brown";
   cardboard8 = createSprite(80,392,100,20);
   cardboard8.shapeColor = "brown";
   cardboard9 = createSprite(200,130,20,50);
   cardboard9.shapeColor = "brown";
   cardboard10 = createSprite(340,150,100,20);
   cardboard10.shapeColor = "brown";
   cardboard11 = createSprite(180,392,100,20);
   cardboard11.shapeColor = "brown";
   cardboard12 = createSprite(400,125,20,100);
   cardboard12.shapeColor = "brown";
   cardboard13 = createSprite(490,250,20,100);
   cardboard13.shapeColor = "brown";
   cardboard14 = createSprite(335,80,150,20);
   cardboard14.shapeColor = "brown";
   cardboard15 = createSprite(100,290,20,90);
   cardboard15.shapeColor = "brown";
   cardboard16 = createSprite(4500,310,100,20);
   cardboard16.shapeColor = "brown";
   cardboard17 = createSprite(30,352,20,100);
   cardboard17.shapeColor = "brown";
   cardboard18 = createSprite(190,350,20,100);
   cardboard18.shapeColor = "brown";
   cardboard19 = createSprite(290,290,20,100);
   cardboard19.shapeColor = "brown";
   cardboard20 = createSprite(350,250,120,20);
   cardboard20.shapeColor = "brown";
   cardboard21 = createSprite(250,392,100,20);
   cardboard21.shapeColor = "brown";
   cardboard22 = createSprite(360,352,20,100);
   cardboard22.shapeColor = "brown";
   target = createSprite(1,375,10,50);
  target.shapeColor = "yellow";
  edges =createEdgeSprites();
}

function draw() {
background("black") 
  
  //Rat.velocityX=0
  //Rat.velocityY=0
  
  Cat.velocityX=2
  Cat.velocityY=2
  if(keyDown("UP_ARROW")){
    Rat.velocityX=0
    Rat.velocityY=-4
  }
  if(keyDown("DOWN_ARROW")){
    Rat.velocityX=0
    Rat.velocityY=4
  }
  if(keyDown("RIGHT_ARROW")){
    Rat.velocityX=4
    Rat.velocityY=0
  }
  if(keyDown("LEFT_ARROW")){
    Rat.velocityX=-4
    Rat.velocityY=0
  }
  Rat.bounceOff(cardboard1);
Rat.bounceOff(cardboard2);
Rat.bounceOff(cardboard3);
Rat.bounceOff(cardboard4);
Rat.bounceOff(cardboard5);
Rat.bounceOff(cardboard6);
Rat.bounceOff(cardboard7);
Rat.bounceOff(cardboard8);
Rat.bounceOff(cardboard9);
Rat.bounceOff(cardboard10);
Rat.bounceOff(cardboard11);
Rat.bounceOff(cardboard12);
Rat.bounceOff(cardboard13);
Rat.bounceOff(cardboard14);
Rat.bounceOff(cardboard15);
Rat.bounceOff(cardboard16);
Rat.bounceOff(cardboard17);
Rat.bounceOff(cardboard18);
Rat.bounceOff(cardboard19);
Rat.bounceOff(cardboard20);
Rat.bounceOff(cardboard21);
Rat.bounceOff(cardboard22);

Rat.collide(target);
Rat.bounceOff(edges);

Cat.bounceOff(edges);





  drawSprites()
  
}